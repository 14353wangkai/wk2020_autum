## java基础

- 接口是可以多继承的

- 使用线程

  - 实现runnable接口的run，在创建thread的时候，传入runnable对象

    ```java
    class MyRunnable implements Runnable{
      @Overide
      public void run(){
        //...
      }
    }
    public class MyMain{
      public static void main(String []args){
        MyRunnable instance = new MyRunnable();
        Thread thread = new Thread(instance);
        thread.start();
      }
    }
    ```

    

  - 实现callable接口，这个接口有返回类型，如：

    ```java
    public class MyCallable implements Callable<Integer> {
        public Integer call() {
            return 123;
        }
    }
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        MyCallable mc = new MyCallable();
        FutureTask<Integer> ft = new FutureTask<>(mc);
        Thread thread = new Thread(ft);
        thread.start();
        System.out.println(ft.get());
    }
    ```

    这个方法中，futureTask接收mc实现返回中间值操作，然后thread通过传入ft作为对象，创建thread类

    

  - 继承thread类，实现run方法（thread也即成了runnable）

    ```java
    public class MyThread extends Thread {
        public void run() {
            // ...
        }
    }
    ```

  - 不建议继承thread，建议实现接口

    - Java 不支持多重继承，因此继承了 Thread 类就无法继承其它类，但是可以实现多个接口；
    - 类可能只要求可执行就行，继承整个 Thread 类开销过大？

  


- 并发容器工具类 AQS：JUC的核心

  - CountDownLatch：控制	

- 正则表达式
  - ^, $: 以xx开头，以xx结尾
  - .：匹配任意一个字符
  - +：1到多
  - *：0次以上
  - ？：匹配一个字符0～1次
  - [A-Za-z0-9]：利用中括号限定匹配自负
  - {a}, {a, b}, {a,}：逗号前面的是至少，右边的是至多
  - (xxx): 将多个字符捆绑成一个
  - 常见考题
    - 匹配邮箱
      - ^[A-Za-z0-9]+\.\@[A-Za-z0-9]+\.[A-Za-z0-9]+$
      - 不知道为什么+限定符不能在zsh中使用
    - 匹配ip
      - `^[1-2]{0,1}[0-9]{1,2}\.[1-2]{0,1}[0-9]{1,2}\.`

  



- 并发的场景

  - CPU密集

    - 考虑单核的情况

      ![img](https://upload-images.jianshu.io/upload_images/19895418-8a4d3c815c2abdb1)

      - 发现即便在理想状态下，多线程也没有比单线程快，何况还会有io开销

    - 考虑多核的情况

      - ![img](https://upload-images.jianshu.io/upload_images/19895418-7370e52c09df4d86)

  - 可以得出感性结论，在cpu密集形的请求，线程数=cpu核心数，可以达到最大使用率

- IO密集形

  - 线程会因为io开销导致很长时间不占用cpu

  - ![img](https://upload-images.jianshu.io/upload_images/19895418-c2955cec5fbacf00)

  - 可以看到，如果不把io的时间填补上，cpu其实会有很多情况下处于空闲状态

  - 因此，理论上，最佳线程数就是
    $$
    \frac{1}{CPU利用率} = \frac{IO耗时}{CPU耗时}
    $$
    

- 经验上来说，总线程个数会比理论最佳值多1个