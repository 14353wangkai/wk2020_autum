## mybatis

- 开源的orm框架
- 抽象了jdbc代码，提供了一套api和数据库交互
- 优势
  - 创建数据源
  - 创建mapper
  - 直接调用，自动转换为需要的pojo
- zebra工具
  - 在entity和mapper中修改配置





```java
class Solution { 
    class mycmp implements Comparator<int[]>{
        @Override
        public int compare(int []a, int[] b){
            return a[0]-b[0];
        }
    }
    public int maxEvents(int[][] events) { 
        Arrays.sort(events, new mycmp());
        int cnt = 0;
        Map<Integer, Integer> map = new HashMap<>();
        int n = events.length;
        int cur = 0;
        for(int i = 0;i < n;i++){
            if(map.containsKey(events[i][0]) && events[i][1] < map.get(events[i][0]) ){
                map.replace(events[i][0], events[i][1]);
            }else{
                if(i == 0 || map.get(cur) <= events[i][0])  
                {
                    map.put(events[i][0], events[i][1]);
                    cur = events[i][0];
                    cnt++;
                }
                else{
                    int tmp = Math.min(events[i][1], map.get(cur));
                    map.replace(cur, tmp);
                }
            }
        }
        for(Map.Entry<Integer, Integer> e:map.entrySet()){
            System.out.println(e.getKey()+" "+e.getValue());
        }
        return cnt;
    }
}
```

