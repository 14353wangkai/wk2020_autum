## 没时间做的每日一题

#### [面试题 16.18. 模式匹配](https://leetcode-cn.com/problems/pattern-matching-lcci/)

```java
class Solution {
        public boolean patternMatching(String pattern, String value) {
            int count_a = 0, count_b = 0;
            for (char ch: pattern.toCharArray()) {
                if (ch == 'a') {
                    ++count_a;
                } else {
                    ++count_b;
                }
            }
            if (count_a < count_b) {
                int temp = count_a;
                count_a = count_b;
                count_b = temp;
                char[] array = pattern.toCharArray();
                for (int i = 0; i < array.length; i++) {
                    array[i] = array[i] == 'a' ? 'b' : 'a';
                }
                pattern = new String(array);
            }
            if (value.length() == 0) {
                return count_b == 0;
            }
            if (pattern.length() == 0) {
                return false;
            }
            for (int len_a = 0; count_a * len_a <= value.length(); ++len_a) {
                int rest = value.length() - count_a * len_a;
                if ((count_b == 0 && rest == 0) || (count_b != 0 && rest % count_b == 0)) {
                    int len_b = (count_b == 0 ? 0 : rest / count_b);
                    int pos = 0;
                    boolean correct = true;
                    String value_a = "", value_b = "";
                    for (char ch: pattern.toCharArray()) {
                        if (ch == 'a') {
                            String sub = value.substring(pos, pos + len_a);
                            if (value_a.length() == 0) {
                                value_a = sub;
                            } else if (!value_a.equals(sub)) {
                                correct = false;
                                break;
                            }
                            pos += len_a;
                        } else {
                            String sub = value.substring(pos, pos + len_b);
                            if (value_b.length() == 0) {
                                value_b = sub;
                            } else if (!value_b.equals(sub)) {
                                correct = false;
                                break;
                            }
                            pos += len_b;
                        }
                    }
                    if (correct && !value_a.equals(value_b)) {
                        return true;
                    }
                }
            }
            return false;
        }
    } 
```





### 最长有效括号匹配

https://leetcode-cn.com/problems/longest-valid-parentheses/

- 括号匹配充要条件（规律）
  - 规律1:在一段长度以内，左右括号数量是相同的
  - 规律2:直到最后一个字符为止，每一个前缀的左括号数量都大于右括号的数量

- 题解框架
  - 将字符串分割为一系列字串，确保每一段都不会破坏规则
- 题解思路
  - 根据规律2，确保当前子串的前缀是左括号更多。我们可以一个个字符串向后遍历，使用一个计数器`cnt`统计左右括号的差值，当遇到左边括号计数器就+1，右边就-1，`cnt<0`的时候说明当前子串再向右就一定不合法了，因为至少有一个前缀是不符合规律2的。
  - 通过规律2，子串可以划分成若干段，并且段与段之间是不能跨越的（注意，最后一个字符一定是右括号，除非没有右括号）
  - 再将这些段结合规律1来进行匹配
  - 规律1对应的是括号匹配题目的常见算法，我们可以利用一个栈，遇到做括号，就装入做括号，遇到右括号，就将栈顶的做括号抛弃，再次注意，这个匹配机制是针对每一段而言的
- 实现：栈

```java
class Solution {
    public int longestValidParentheses(String s) {
        int res = 0, n = s.length();
        Stack<Integer> stack = new Stack<>();
        int start = -1;
        for(int i =  0;i < n;i++){
            if(s.charAt(i)=='('){
                stack.push(i);
            }else{
                if(!stack.isEmpty()){
                    stack.pop();
                    int tmp = 0;
                    if(!stack.isEmpty())            
                        tmp = i - stack.peek();
                    else                                //整段都满足情况
                        tmp = i - start;    
                    res = res > tmp?res:tmp;
                }
                else{
                    start = i;
                }
                
            }
        }
        return res;
    }
}
```



实现：左右扫描法（更快，且逻辑更好记）

- 细节：左右括号指针相互追逐，相遇的时候计算一下长度。

```java
public class Solution {
    public int longestValidParentheses(String s) {
        int left = 0, right = 0, maxlength = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '(') {
                left++;
            } else {
                right++;
            }
            if (left == right) {
                maxlength = Math.max(maxlength, 2 * right);
            } else if (right > left) {
                left = right = 0;
            }
        }
        left = right = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            if (s.charAt(i) == '(') {
                left++;
            } else {
                right++;
            }
            if (left == right) {
                maxlength = Math.max(maxlength, 2 * left);
            } else if (left > right) {
                left = right = 0;
            }
        }
        return maxlength;
    }
}
```



## 最长交叉路径

- 题意：从树的**任意一个节点出发**，每次向下遍历都必须交叉进行，求最长距离。
- 题解：设置一个全局最大值，每次保存最佳状态即可，要注意的是，这题是不能对每一个节点都进行深搜的，这种暴力做法会导致超时，对此我们可以剪枝，每次遇到没有‘交替’子节点的时候，就把路径长度设为1，相当于新的一次遍历，这样的话，每个节点其实只会被遍历一次。

```java
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
class Solution {
    int max = 0;

    void dfs(TreeNode root, int depth, int state){
        max = Math.max(max, depth);
        if(root == null) return;
      
        if(state == 0 && root.right == null) dfs(root.left, 1, state);
        else if(state == 1 && root.left == null) dfs(root.right, 1, state);
        
        else if(state == 0) {
            dfs(root.right, depth+1, 1);
            dfs(root.left, 1, 0);
        }
        else {
            dfs(root.left, depth+1, 0);
            dfs(root.right, 1, 1);
        }
    }
    public int longestZigZag(TreeNode root) { 
        if(root == null || root.left == null && root.right==null) return 0;
        dfs(root, 0, 0);
        dfs(root, 0, 1);         
        return max;
    }
}
```

